# LocalFocus Widget API

## Do cool stuff with LocalFocus Widgets!

Your co-workers add datasets to LocalFocus, create charts and embed these on your companies website. Great!
But you know javascript and want to interact with these charts on your webpages.

Visit [developers.localfocus.nl](http://developers.localfocus.nl) for the documentation.